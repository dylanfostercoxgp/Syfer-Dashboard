"""
Syfer Orchestrator — Two-Stage Lead Pipeline

Stage 1: Scouts return raw DDGS results
Stage 2: Each result is classified:
  - 'company'   → extract contacts → insert to DB
  - 'blog'      → extract company names from page → search each → re-classify
  - 'directory' → extract business names → search each → re-classify
  - 'skip'      → discard

Usage:
    python main.py                  # Full run
    python main.py --type corporate
    python main.py --quick          # Fewer queries per scout
"""

import sys
import os
import time
import argparse
from urllib.parse import urlparse

sys.path.insert(0, os.path.dirname(__file__))

from ddgs import DDGS

import db_manager
import corporate_scout
import medical_scout
import outdoor_scout
import nonprofit_scout
import dashboard_gen
import github_pusher
from lead_classifier import classify, extract_companies_from_blog, extract_companies_from_directory
from contact_extractor import extract_contacts, fetch_page

SCOUT_MAP = {
    'corporate': corporate_scout,
    'medical':   medical_scout,
    'outdoor':   outdoor_scout,
    'nonprofit': nonprofit_scout,
}

CITIES = [
    'Denver', 'Boulder', 'Fort Collins', 'Colorado Springs',
    'Aurora', 'Lakewood', 'Arvada', 'Westminster', 'Thornton',
    'Highlands Ranch', 'Broomfield', 'Longmont', 'Loveland',
    'Greeley', 'Englewood', 'Littleton',
]


def parse_city(text: str) -> str:
    text_lower = text.lower()
    for city in CITIES:
        if city.lower() in text_lower:
            return city
    return 'Denver'


def clean_name(title: str) -> str:
    for sep in [' - ', ' | ', ' – ', ' — ', ' · ', ' :: ']:
        if sep in title:
            title = title.split(sep)[0]
    return title.strip()[:120]


def process_company_result(result: dict, ddgs, run_id: int) -> int:
    """
    Takes a classified 'company' result dict, extracts contacts,
    inserts into DB. Returns 1 if new lead inserted, else 0.
    """
    url   = result.get('url', '')
    title = result.get('title', '')
    body  = result.get('body', '')
    org_type = result.get('org_type', 'General')
    query = result.get('query', '')

    # Score using the right scout's scoring logic
    scout_mod = SCOUT_MAP.get(org_type.lower())
    score_val = 5
    if scout_mod and hasattr(scout_mod, 'score'):
        score_val = scout_mod.score(title, body)

    org_name = clean_name(title)
    city     = parse_city(body + ' ' + title)

    # Extract email
    contacts = {'email': ''}
    if url.startswith('http'):
        contacts = extract_contacts(url)
        time.sleep(0.4)

    lead = {
        'org_name':     org_name,
        'org_type':     org_type,
        'city':         city,
        'state':        'CO',
        'website':      url,
        'email':        contacts['email'],
        'source_query': query,
        'description':  body[:300],
        'score':        score_val,
    }

    lead_id = db_manager.insert_lead(lead, run_id=run_id)
    return 1 if lead_id else 0


def process_secondary_company(name: str, url: str, org_type: str, query: str,
                               ddgs, run_id: int) -> int:
    """
    For a company found inside a blog/directory, look up their actual
    website if we don't have it, then insert as a lead.
    """
    # If we already have a URL from a link in the article, use it
    if url and url.startswith('http'):
        try:
            domain = urlparse(url).netloc.replace('www.', '')
            kind = classify(url, name, '')
            if kind in ('blog', 'directory', 'skip'):
                url = ''  # Don't use it, fall through to search
        except Exception:
            url = ''

    # Search for the company if no direct URL
    if not url:
        search_q = f'"{name}" Colorado company website'
        try:
            hits = ddgs.text(search_q, max_results=3)
            for h in (hits or []):
                candidate_url = h.get('href', '')
                kind = classify(candidate_url, h.get('title', ''), h.get('body', ''))
                if kind == 'company':
                    url = candidate_url
                    break
            time.sleep(0.5)
        except Exception:
            pass

    if not url:
        return 0

    contacts = extract_contacts(url)
    time.sleep(0.4)

    lead = {
        'org_name':     clean_name(name),
        'org_type':     org_type,
        'city':         'Denver',  # Default — article didn't specify
        'state':        'CO',
        'website':      url,
        'email':        contacts['email'],
        'source_query': query,
        'description':  f'Found via article/directory listing.',
        'score':        6,  # Reasonable default for secondary finds
    }

    lead_id = db_manager.insert_lead(lead, run_id=run_id)
    return 1 if lead_id else 0


def run_scouts(run_type: str = 'Full', quick: bool = False) -> dict:
    db_manager.init_db()
    run_id = db_manager.start_run(run_type)
    start_time = time.time()

    print(f"\n{'='*62}")
    print(f"  SYFER — Run #{run_id} | {run_type} | {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*62}\n")

    limit = 3 if quick else 5

    scouts_to_run = (
        list(SCOUT_MAP.items()) if run_type == 'Full'
        else [(run_type.lower(), SCOUT_MAP[run_type.lower()])]
        if run_type.lower() in SCOUT_MAP else []
    )

    total_new    = 0
    total_found  = 0
    total_emails = 0
    blogs_processed = 0
    secondary_leads = 0

    with DDGS() as ddgs:
        for scout_name, scout_mod in scouts_to_run:
            print(f"\n[Syfer] {scout_name.capitalize()} Scout starting...")

            raw_results = scout_mod.run(ddgs, limit_per_query=limit)
            scout_new = 0
            scout_emails = 0

            for result in raw_results:
                url   = result.get('url', '')
                title = result.get('title', '')
                body  = result.get('body', '')

                kind = classify(url, title, body)

                if kind == 'company':
                    new = process_company_result(result, ddgs, run_id)
                    scout_new += new
                    if new:
                        # Check if email was captured
                        pass  # tracked via DB

                elif kind in ('blog', 'directory'):
                    blogs_processed += 1
                    html = fetch_page(url)
                    if not html:
                        continue

                    if kind == 'blog':
                        base_domain = urlparse(url).netloc.replace('www.', '')
                        companies = extract_companies_from_blog(html, base_domain)
                    else:
                        companies = extract_companies_from_directory(html, url)

                    print(f"  [Stage2] {kind.capitalize()} '{title[:45]}...' → {len(companies)} companies")

                    for co in companies:
                        new = process_secondary_company(
                            co['name'], co['url'],
                            result.get('org_type', 'General'),
                            result.get('query', ''),
                            ddgs, run_id
                        )
                        scout_new += new
                        secondary_leads += new

                elif kind == 'skip':
                    continue

                total_found += 1

            print(f"  [{scout_name.capitalize()}] +{scout_new} new leads")
            total_new += scout_new

    # Final counts from DB
    conn_stats = db_manager.update_daily_stats()
    total_emails = conn_stats['emails']
    duration = time.time() - start_time

    db_manager.finish_run(run_id, total_found, total_new, total_emails, duration)

    print(f"\n{'='*62}")
    print(f"  Run Complete — {duration:.1f}s")
    print(f"  Results processed: {total_found} | New leads: {total_new}")
    print(f"  Blog/directory pages mined: {blogs_processed} ({secondary_leads} secondary leads)")
    print(f"  Emails in DB: {total_emails} | Total leads: {conn_stats['total']}")
    print(f"{'='*62}\n")

    # Generate dashboard
    print("[Syfer] Generating dashboard...")
    output_path = os.path.join(os.path.dirname(__file__), '..', 'output', 'dashboard.html')
    dashboard_gen.generate(output_path)
    print(f"[Syfer] Dashboard saved → {output_path}")

    # Auto-push to GitHub Pages
    print("[Syfer] Pushing dashboard to GitHub Pages...")
    github_pusher.push(output_path)

    return dict(run_id=run_id, total_new=total_new, emails=total_emails,
                blogs_mined=blogs_processed, secondary_leads=secondary_leads,
                stats=conn_stats, dashboard_path=output_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Syfer Lead Scout')
    parser.add_argument('--type', default='Full',
                        choices=['Full', 'corporate', 'medical', 'outdoor', 'nonprofit'])
    parser.add_argument('--quick', action='store_true', help='Fewer queries, faster demo')
    args = parser.parse_args()
    run_scouts(run_type=args.type, quick=args.quick)
