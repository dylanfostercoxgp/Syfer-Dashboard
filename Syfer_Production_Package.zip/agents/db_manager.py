"""
Syfer Database Manager — SQLite backend.
Stores leads, run history, and daily stats.
"""

import os
import sqlite3
from datetime import datetime, date

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'syfer.db')


def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute('''
        CREATE TABLE IF NOT EXISTS leads (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            org_name     TEXT NOT NULL,
            org_type     TEXT DEFAULT 'General',
            city         TEXT DEFAULT '',
            state        TEXT DEFAULT 'CO',
            website      TEXT DEFAULT '',
            email        TEXT DEFAULT '',
            contact_name TEXT DEFAULT '',
            source_query TEXT DEFAULT '',
            description  TEXT DEFAULT '',
            score        INTEGER DEFAULT 5,
            status       TEXT DEFAULT 'New',
            found_date   TEXT,
            first_seen   TEXT DEFAULT (datetime('now')),
            last_seen    TEXT DEFAULT (datetime('now')),
            run_id       INTEGER
        )
    ''')

    c.execute('CREATE INDEX IF NOT EXISTS idx_org ON leads(org_name, city)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_type ON leads(org_type)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_found_date ON leads(found_date)')

    c.execute('''
        CREATE TABLE IF NOT EXISTS run_log (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            run_date     TEXT DEFAULT (datetime('now')),
            run_type     TEXT DEFAULT 'Full',
            leads_found  INTEGER DEFAULT 0,
            leads_new    INTEGER DEFAULT 0,
            emails_found INTEGER DEFAULT 0,
            duration_sec REAL DEFAULT 0,
            status       TEXT DEFAULT 'Running'
        )
    ''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS daily_stats (
            stat_date     TEXT PRIMARY KEY,
            total_leads   INTEGER DEFAULT 0,
            new_today     INTEGER DEFAULT 0,
            high_priority INTEGER DEFAULT 0,
            warm          INTEGER DEFAULT 0,
            contacted     INTEGER DEFAULT 0,
            booked        INTEGER DEFAULT 0,
            emails        INTEGER DEFAULT 0
        )
    ''')

    conn.commit()
    conn.close()
    print(f"[DB] Initialized at {DB_PATH}")


def insert_lead(data: dict, run_id: int = None):
    conn = get_conn()
    c = conn.cursor()
    today = date.today().isoformat()

    org_name = (data.get('org_name') or '').strip()[:120]
    city     = (data.get('city') or 'Denver').strip()

    if not org_name:
        conn.close()
        return None

    c.execute(
        'SELECT id, email FROM leads WHERE LOWER(org_name)=LOWER(?) AND LOWER(city)=LOWER(?)',
        (org_name, city)
    )
    existing = c.fetchone()

    if existing:
        new_email = (data.get('email') or '').strip()
        if new_email and not existing['email']:
            c.execute('UPDATE leads SET email=?, last_seen=? WHERE id=?',
                      (new_email, datetime.now().isoformat(), existing['id']))
            conn.commit()
        conn.close()
        return None

    c.execute('''
        INSERT INTO leads
          (org_name, org_type, city, state, website, email,
           source_query, description, score, found_date, run_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    ''', (
        org_name,
        data.get('org_type', 'General'),
        city,
        data.get('state', 'CO'),
        (data.get('website') or '').strip()[:300],
        (data.get('email') or '').strip(),
        (data.get('source_query') or '').strip()[:200],
        (data.get('description') or '').strip()[:300],
        int(data.get('score', 5)),
        today,
        run_id,
    ))
    new_id = c.lastrowid
    conn.commit()
    conn.close()
    return new_id


def start_run(run_type: str = 'Full') -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute('INSERT INTO run_log (run_type, status) VALUES (?, ?)', (run_type, 'Running'))
    run_id = c.lastrowid
    conn.commit()
    conn.close()
    return run_id


def finish_run(run_id: int, leads_found: int, leads_new: int, emails_found: int, duration: float):
    conn = get_conn()
    c = conn.cursor()
    c.execute('''
        UPDATE run_log
        SET leads_found=?, leads_new=?, emails_found=?, duration_sec=?, status='Complete'
        WHERE id=?
    ''', (leads_found, leads_new, emails_found, duration, run_id))
    conn.commit()
    conn.close()


def update_daily_stats() -> dict:
    today = date.today().isoformat()
    conn = get_conn()
    c = conn.cursor()

    def count(q, *args):
        c.execute(q, args)
        return c.fetchone()[0]

    total        = count('SELECT COUNT(*) FROM leads')
    new_today    = count('SELECT COUNT(*) FROM leads WHERE found_date=?', today)
    high_priority= count('SELECT COUNT(*) FROM leads WHERE score >= 8')
    warm         = count("SELECT COUNT(*) FROM leads WHERE status='Warm'")
    contacted    = count("SELECT COUNT(*) FROM leads WHERE status='Contacted'")
    booked       = count("SELECT COUNT(*) FROM leads WHERE status='Booked'")
    emails       = count("SELECT COUNT(*) FROM leads WHERE email != ''")

    c.execute('''
        INSERT INTO daily_stats
          (stat_date, total_leads, new_today, high_priority, warm, contacted, booked, emails)
        VALUES (?,?,?,?,?,?,?,?)
        ON CONFLICT(stat_date) DO UPDATE SET
          total_leads=excluded.total_leads, new_today=excluded.new_today,
          high_priority=excluded.high_priority, warm=excluded.warm,
          contacted=excluded.contacted, booked=excluded.booked, emails=excluded.emails
    ''', (today, total, new_today, high_priority, warm, contacted, booked, emails))

    conn.commit()
    conn.close()
    return dict(total=total, new_today=new_today, high_priority=high_priority,
                warm=warm, contacted=contacted, booked=booked, emails=emails)


def get_leads_by_date(target_date: str, limit: int = 500) -> list:
    conn = get_conn()
    c = conn.cursor()
    c.execute('''
        SELECT * FROM leads WHERE found_date=?
        ORDER BY score DESC, first_seen ASC LIMIT ?
    ''', (target_date, limit))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_all_dates() -> list:
    conn = get_conn()
    c = conn.cursor()
    c.execute('''
        SELECT found_date as date, COUNT(*) as count
        FROM leads WHERE found_date IS NOT NULL
        GROUP BY found_date ORDER BY found_date DESC
    ''')
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_all_leads(limit: int = 1000) -> list:
    conn = get_conn()
    c = conn.cursor()
    c.execute('SELECT * FROM leads ORDER BY score DESC, first_seen DESC LIMIT ?', (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_recent_runs(n: int = 10) -> list:
    conn = get_conn()
    c = conn.cursor()
    c.execute('SELECT * FROM run_log ORDER BY id DESC LIMIT ?', (n,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_stats_for_date(target_date: str) -> dict:
    conn = get_conn()
    c = conn.cursor()

    def count(q, *args):
        c.execute(q, args)
        return c.fetchone()[0]

    new    = count("SELECT COUNT(*) FROM leads WHERE found_date=?", target_date)
    high   = count("SELECT COUNT(*) FROM leads WHERE found_date=? AND score >= 8", target_date)
    emails = count("SELECT COUNT(*) FROM leads WHERE found_date=? AND email != ''", target_date)

    c.execute("SELECT org_type, COUNT(*) as n FROM leads WHERE found_date=? GROUP BY org_type", (target_date,))
    by_type = {row['org_type']: row['n'] for row in c.fetchall()}

    conn.close()
    return dict(new=new, high_priority=high, emails=emails, by_type=by_type)
