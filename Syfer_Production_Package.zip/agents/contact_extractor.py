"""
Syfer Contact Extractor
Scrapes a website URL and extracts email addresses only.
"""

import re
import requests
from bs4 import BeautifulSoup

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    )
}

EMAIL_RE = re.compile(
    r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'
)

SKIP_EMAIL_DOMAINS = {
    'example.com', 'sentry.io', 'wixpress.com', 'squarespace.com',
    'wordpress.com', 'adobe.com', 'cloudflare.com', 'google.com',
    'schema.org', 'w3.org', 'jquery.com', 'facebook.com', 'twitter.com',
    'instagram.com', 'linkedin.com', 'youtube.com',
}

SKIP_EMAIL_PREFIXES = {
    'noreply', 'no-reply', 'donotreply', 'privacy@', 'legal@', 'abuse@',
}


def fetch_page(url: str, timeout: int = 10) -> str | None:
    try:
        r = requests.get(url, headers=HEADERS, timeout=timeout)
        if r.status_code == 200:
            return r.text
    except Exception:
        pass
    return None


def extract_contacts(url: str) -> dict:
    """
    Fetch a URL and return dict with:
      email: str (best email or '')
      all_emails: list
    """
    html = fetch_page(url)
    if not html:
        return {'email': '', 'all_emails': []}

    # Also try /contact page
    contact_html = ''
    base = url.rstrip('/')
    for suffix in ['/contact', '/contact-us', '/about', '/about-us']:
        contact_page = fetch_page(base + suffix, timeout=8)
        if contact_page:
            contact_html = contact_page
            break

    combined = html + contact_html

    soup = BeautifulSoup(combined, 'lxml')
    for tag in soup(['script', 'style']):
        tag.decompose()
    text = soup.get_text(separator=' ')

    raw_emails = EMAIL_RE.findall(text)
    emails = []
    seen = set()
    for e in raw_emails:
        e = e.lower().strip('.')
        domain = e.split('@')[-1]
        if domain in SKIP_EMAIL_DOMAINS:
            continue
        if any(e.startswith(p) for p in SKIP_EMAIL_PREFIXES):
            continue
        if e not in seen:
            seen.add(e)
            emails.append(e)

    return {
        'email': emails[0] if emails else '',
        'all_emails': emails[:5],
    }
