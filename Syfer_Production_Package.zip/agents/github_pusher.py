"""
Syfer GitHub Pusher
Uploads the generated dashboard (index.html) to a GitHub repository after every run.
GitHub Pages then serves it automatically as a live URL — no server access needed.

Setup (one time):
  1. Create a free GitHub account at github.com
  2. Create a new repository (e.g. "syfer-dashboard"), set it to Public
  3. Enable GitHub Pages: repo Settings → Pages → Source: Deploy from branch → main → / (root)
  4. Create a Personal Access Token: github.com → Settings → Developer Settings →
     Personal access tokens → Tokens (classic) → Generate new token
     Scopes needed: check "repo"
  5. Fill in syfer_config.json with your github_owner, github_repo, and github_token

Your dashboard will live at:  https://YOUR_USERNAME.github.io/syfer-dashboard/
"""

import os
import json
import base64
import urllib.request
import urllib.error

CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'syfer_config.json')


def load_config():
    if not os.path.exists(CONFIG_PATH):
        print("[GitHub] syfer_config.json not found — skipping upload.")
        return None
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)


def _api_request(url, token, method='GET', data=None):
    """Simple GitHub API request using urllib (no extra dependencies)."""
    req = urllib.request.Request(url)
    req.add_header('Authorization', f'token {token}')
    req.add_header('Accept', 'application/vnd.github.v3+json')
    req.add_header('Content-Type', 'application/json')
    req.method = method

    body = json.dumps(data).encode('utf-8') if data else None
    try:
        with urllib.request.urlopen(req, data=body, timeout=30) as resp:
            return json.loads(resp.read().decode('utf-8')), resp.status
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        return json.loads(body) if body else {}, e.code


def push(local_html_path: str) -> bool:
    """
    Upload local_html_path to GitHub as index.html.
    Returns True on success, False on failure.
    """
    cfg = load_config()
    if not cfg:
        return False

    gh = cfg.get('github', {})
    owner = gh.get('owner', '')
    repo  = gh.get('repo', '')
    token = gh.get('token', '')
    path  = gh.get('file_path', 'index.html')

    if not owner or not repo or not token:
        print("[GitHub] Missing credentials in syfer_config.json — skipping upload.")
        print("         Fill in: github.owner, github.repo, github.token")
        return False

    if owner == 'your_github_username':
        print("[GitHub] Config not filled in yet — skipping upload.")
        return False

    if not os.path.exists(local_html_path):
        print(f"[GitHub] Local file not found: {local_html_path}")
        return False

    with open(local_html_path, 'rb') as f:
        content_b64 = base64.b64encode(f.read()).decode('utf-8')

    api_url = f'https://api.github.com/repos/{owner}/{repo}/contents/{path}'

    # Get current file SHA (needed for updates)
    existing, status = _api_request(api_url, token)
    sha = existing.get('sha') if status == 200 else None

    from datetime import date
    commit_msg = f'Syfer update — {date.today().isoformat()}'

    payload = {
        'message': commit_msg,
        'content': content_b64,
    }
    if sha:
        payload['sha'] = sha

    print(f"[GitHub] Pushing dashboard to {owner}/{repo} ...")
    result, status = _api_request(api_url, token, method='PUT', data=payload)

    if status in (200, 201):
        pages_url = f'https://{owner}.github.io/{repo}/'
        print(f"[GitHub] ✓ Dashboard live → {pages_url}")
        return True
    else:
        print(f"[GitHub] Push failed (HTTP {status}): {result.get('message', 'Unknown error')}")
        return False


if __name__ == '__main__':
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else '../output/dashboard.html'
    push(os.path.abspath(path))
