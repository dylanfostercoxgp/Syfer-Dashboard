"""
Syfer FTP Pusher
Uploads the generated dashboard (index.html) to your web server after every run.
Fill in syfer_config.json with your FTP credentials once — then it's fully automatic.
"""

import ftplib
import os
import json
import sys

CONFIG_PATH = os.path.join(os.path.dirname(__file__), '..', 'syfer_config.json')


def load_config():
    if not os.path.exists(CONFIG_PATH):
        print("[FTP] syfer_config.json not found — skipping upload.")
        print(f"      Expected at: {os.path.abspath(CONFIG_PATH)}")
        return None
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)


def push(local_html_path: str) -> bool:
    """
    Upload local_html_path to the server as index.html.
    Returns True on success, False on failure.
    """
    cfg = load_config()
    if not cfg:
        return False

    ftp_cfg = cfg.get('ftp', {})
    host     = ftp_cfg.get('host', '')
    user     = ftp_cfg.get('username', '')
    password = ftp_cfg.get('password', '')
    remote   = ftp_cfg.get('remote_path', '/syfer/index.html')
    port     = int(ftp_cfg.get('port', 21))

    if not host or not user or not password:
        print("[FTP] Missing credentials in syfer_config.json — skipping upload.")
        return False

    if not os.path.exists(local_html_path):
        print(f"[FTP] Local file not found: {local_html_path} — skipping upload.")
        return False

    try:
        print(f"[FTP] Connecting to {host}:{port} ...")
        ftp = ftplib.FTP()
        ftp.connect(host, port, timeout=30)
        ftp.login(user, password)

        # Navigate to the correct remote directory
        remote_dir  = os.path.dirname(remote)
        remote_file = os.path.basename(remote)

        if remote_dir and remote_dir != '/':
            try:
                ftp.cwd(remote_dir)
            except ftplib.error_perm:
                # Directory doesn't exist — create it
                _make_dirs(ftp, remote_dir)
                ftp.cwd(remote_dir)

        # Upload the file
        with open(local_html_path, 'rb') as f:
            ftp.storbinary(f'STOR {remote_file}', f)

        ftp.quit()
        print(f"[FTP] ✓ Dashboard uploaded → {host}{remote}")
        return True

    except ftplib.all_errors as e:
        print(f"[FTP] Upload failed: {e}")
        return False


def _make_dirs(ftp, path):
    """Recursively create remote directories."""
    parts = [p for p in path.split('/') if p]
    current = '/'
    for part in parts:
        current = current.rstrip('/') + '/' + part
        try:
            ftp.mkd(current)
        except ftplib.error_perm:
            pass  # Already exists


if __name__ == '__main__':
    # Test: python ftp_pusher.py ../output/dashboard.html
    path = sys.argv[1] if len(sys.argv) > 1 else '../output/dashboard.html'
    push(os.path.abspath(path))
