"""
Syfer — Corporate Scout
Returns raw DDGS search results for corporate group targets.
Classification, extraction, and DB insertion handled by orchestrator.
"""

ORG_TYPE = 'Corporate'

QUERIES = [
    'Denver corporate retreat planning company Colorado',
    'Denver HR department team building events company',
    'Denver event planning company corporate groups',
    'Denver tech company headquarters Colorado groups',
    'Denver financial services firm Colorado retreat',
    'Denver law firm Colorado group retreat',
    'Denver oil gas energy company Colorado',
    'Boulder Colorado tech company corporate events',
    'Boulder Colorado company HR offsite retreat',
    'Fort Collins Colorado company corporate events',
    'Fort Collins business corporate retreat Colorado',
    'Colorado Springs corporate event planning company',
    'Colorado Springs defense contractor company Colorado',
    'Front Range Colorado corporate group travel planner',
    'Colorado company annual retreat planning firm',
    'Denver incentive travel corporate group company',
    'Colorado corporate wellness retreat company',
    'Denver large employer corporate group travel',
    'Denver executive retreat planning company Colorado',
    'Colorado leadership retreat corporate company',
    'Denver association management company Colorado',
    'Colorado meeting planning company group events',
    'Denver corporate team building company Front Range',
]

SCORE_SIGNALS = [
    ('team building', 2),
    ('corporate retreat', 3),
    ('annual retreat', 3),
    ('incentive travel', 3),
    ('group travel', 2),
    ('offsite', 2),
    ('event planner', 2),
    ('hr director', 2),
    ('hr manager', 2),
    ('employee experience', 2),
    ('company outing', 2),
    ('executive retreat', 3),
    ('wellness retreat', 2),
    ('leadership retreat', 3),
    ('headquarters', 1),
    ('planning company', 2),
    ('group events', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    """Return raw search result dicts."""
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':     r.get('title', '').strip(),
                    'body':      r.get('body', '').strip(),
                    'url':       url,
                    'query':     query,
                    'org_type':  ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[CorporateScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[CorporateScout] {len(results)} raw results")
    return results
