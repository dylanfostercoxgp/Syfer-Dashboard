"""
Syfer — Nonprofit Scout
Returns raw DDGS search results for nonprofit/association group targets.
"""

ORG_TYPE = 'Nonprofit'

QUERIES = [
    'Denver nonprofit foundation organization Colorado',
    'Denver nonprofit organization Colorado annual retreat',
    'Colorado nonprofit association organization',
    'Denver charitable foundation Colorado organization',
    'Denver community foundation Colorado organization',
    'Denver Chamber of Commerce Colorado organization',
    'Boulder Chamber of Commerce Colorado organization',
    'Fort Collins Chamber of Commerce Colorado organization',
    'Colorado Springs Chamber of Commerce organization',
    'Colorado civic organization leadership group',
    'Colorado Rotary club organization Denver',
    'Denver Lions club Colorado organization',
    'Colorado professional association organization',
    'Denver trade association Colorado organization',
    'Colorado bar association member organization',
    'Colorado realtors association organization Denver',
    'Colorado builders association organization',
    'Denver church group Colorado organization',
    'Colorado large congregation church organization',
    'Colorado school district administrative group',
    'Denver alumni association Colorado organization',
    'Colorado fraternal organization Denver',
    'Denver women professional organization Colorado',
    'Denver leadership program organization Colorado',
    'Colorado homebuilders association Denver organization',
]

SCORE_SIGNALS = [
    ('nonprofit', 2),
    ('foundation', 2),
    ('annual retreat', 3),
    ('board retreat', 3),
    ('leadership retreat', 3),
    ('chamber of commerce', 3),
    ('association', 2),
    ('501(c)', 3),
    ('executive director', 2),
    ('board of directors', 2),
    ('membership organization', 2),
    ('civic organization', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[NonprofitScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[NonprofitScout] {len(results)} raw results")
    return results
