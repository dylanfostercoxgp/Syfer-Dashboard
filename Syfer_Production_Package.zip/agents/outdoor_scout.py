"""
Syfer — Outdoor Scout
Returns raw DDGS search results for outdoor group targets.
"""

ORG_TYPE = 'Outdoor'

QUERIES = [
    'Colorado hunting club Denver Front Range organization',
    'Colorado hunting outfitter company Denver Boulder',
    'Denver hunting fishing club Colorado membership organization',
    'Colorado elk hunting club organization Denver',
    'Colorado sportsman club Front Range organization',
    'Denver ski club Colorado mountain group organization',
    'Front Range ski club Denver snowboard group',
    'Denver snowmobile club Colorado organization',
    'Colorado snowmobile association organization',
    'Colorado off road club Denver 4x4 organization',
    'Colorado ATV side-by-side club Denver organization',
    'Denver jeep club Colorado off road group',
    'Colorado overland group Denver adventure club',
    'Denver hiking club Colorado group organization',
    'Colorado fourteener climbing club Denver organization',
    'Denver trail running club Colorado organization',
    'Colorado mountain biking club Denver Boulder organization',
    'Boulder outdoor recreation club Colorado organization',
    'Colorado adventure travel company Denver group',
    'Front Range outdoor adventure company Colorado',
    'Denver golf club private Colorado organization',
    'Colorado golf association Denver group organization',
    'Colorado equestrian club Denver Front Range organization',
    'Denver fly fishing club Colorado organization',
    'Colorado backcountry hunting club organization',
]

SCORE_SIGNALS = [
    ('hunting', 3),
    ('elk', 3),
    ('snowmobile', 4),
    ('side-by-side', 4),
    ('atv', 3),
    ('off road', 3),
    ('ski club', 3),
    ('golf club', 2),
    ('outfitter', 3),
    ('adventure travel', 3),
    ('group trip', 3),
    ('annual trip', 3),
    ('club membership', 2),
    ('fly fishing', 3),
    ('backcountry', 3),
    ('wilderness', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[OutdoorScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[OutdoorScout] {len(results)} raw results")
    return results
