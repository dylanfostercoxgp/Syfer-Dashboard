"""
Syfer — Medical Scout
Returns raw DDGS search results for medical group targets.
"""

ORG_TYPE = 'Medical'

QUERIES = [
    'Denver hospital medical center staff retreat Colorado',
    'Denver healthcare system group retreat Colorado',
    'UCHealth Colorado group staff events',
    'Denver Health hospital staff retreat Colorado',
    'Children Hospital Colorado staff group events',
    'Denver medical group physicians practice Colorado',
    'Denver internal medicine group practice Colorado',
    'Denver orthopedic group practice Colorado',
    'Denver cardiology group practice Colorado',
    'Denver dermatology group practice Colorado',
    'Boulder medical group physicians practice Colorado',
    'Fort Collins medical group physicians Colorado',
    'Colorado Springs medical group practice Colorado',
    'Denver dental group multi-location practice Colorado',
    'Denver veterinary group practice Colorado',
    'Colorado veterinary specialty group',
    'Denver pharmaceutical company Colorado office',
    'Denver medical device company Colorado',
    'Colorado health technology company group retreat',
    'Denver surgery center group practice Colorado',
    'Colorado physician group practice management',
    'Denver specialty clinic group practice Colorado',
    'Front Range healthcare group retreat Colorado',
    'Colorado medical association member organization',
    'Denver hospital foundation group Colorado',
]

SCORE_SIGNALS = [
    ('medical group', 3),
    ('physician group', 3),
    ('health system', 2),
    ('hospital', 2),
    ('multi-location', 3),
    ('staff retreat', 3),
    ('group practice', 3),
    ('practice management', 2),
    ('medical center', 2),
    ('specialty group', 2),
    ('healthcare group', 2),
    ('clinical group', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[MedicalScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[MedicalScout] {len(results)} raw results")
    return results
