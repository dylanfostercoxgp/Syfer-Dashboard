"""
Syfer Dashboard Generator
Reads SQLite DB and writes a self-contained HTML dashboard.
Features: date dropdown filter, dark/light theme switcher, per-date stats.
No server required — open dashboard.html in any browser.
"""

import os, sys, json
from datetime import datetime, date
sys.path.insert(0, os.path.dirname(__file__))
import db_manager


def generate(output_path: str = None):
    all_leads  = db_manager.get_all_leads(limit=2000)
    all_dates  = db_manager.get_all_dates()
    stats      = db_manager.update_daily_stats()
    today      = date.today().isoformat()
    now_str    = datetime.now().strftime('%B %d, %Y · %I:%M %p')

    def fmt_date(d):
        try:
            return datetime.strptime(d, '%Y-%m-%d').strftime('%B %d, %Y')
        except Exception:
            return d

    date_options_html = ''
    for row in all_dates:
        d    = row['date']
        cnt  = row['count']
        sel  = 'selected' if d == today else ''
        label = ('Today — ' if d == today else '') + fmt_date(d)
        date_options_html += f'<option value="{d}" {sel}>{label} ({cnt} leads)</option>\n'
    if not all_dates:
        date_options_html = f'<option value="{today}" selected>Today — {fmt_date(today)} (0 leads)</option>'

    leads_json = json.dumps([{
        'id':          l.get('id'),
        'org_name':    l.get('org_name', ''),
        'org_type':    l.get('org_type', 'General'),
        'city':        l.get('city', ''),
        'score':       l.get('score', 5),
        'status':      l.get('status', 'New'),
        'email':       l.get('email', '') or '',
        'website':     l.get('website', '') or '',
        'description': (l.get('description', '') or '')[:90],
        'found_date':  l.get('found_date', '') or '',
    } for l in all_leads])

    html = f'''<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Syfer · Saratoga Hot Springs Resort</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Inter:wght@300;400;500;600;700&display=swap');

  /* ── THEME VARIABLES ── */
  :root, [data-theme="dark"] {{
    --bg-page:        #0c0c0c;
    --bg-surface:     #111111;
    --bg-surface-2:   #0d0d0d;
    --bg-input:       #0c0c0c;
    --bg-row-hover:   #141414;
    --bg-copy:        #1a1a1a;
    --border:         #1e1e1e;
    --border-subtle:  #161616;
    --border-input:   #222222;
    --border-copy:    #2a2a2a;
    --text-primary:   #e0dbd3;
    --text-secondary: #555555;
    --text-muted:     #444444;
    --text-faint:     #3a3a3a;
    --text-org:       #e8e3db;
    --text-org-desc:  #3a3a3a;
    --text-th:        #3a3a3a;
    --text-sep:       #2a2a2a;
    --score-bar-bg:   #222222;
    --email-dash:     #2a2a2a;
    --shadow-toast:   rgba(0,0,0,.5);
    --theme-icon:     "☀";
    --theme-label:    "Light Mode";
  }}

  [data-theme="light"] {{
    --bg-page:        #f4f3ef;
    --bg-surface:     #ffffff;
    --bg-surface-2:   #f8f7f4;
    --bg-input:       #f4f3ef;
    --bg-row-hover:   #faf9f7;
    --bg-copy:        #ede9e3;
    --border:         #e2ddd6;
    --border-subtle:  #ece8e2;
    --border-input:   #d8d3cc;
    --border-copy:    #ccc8c0;
    --text-primary:   #1a1714;
    --text-secondary: #6b6560;
    --text-muted:     #7a7570;
    --text-faint:     #8a8580;
    --text-org:       #111111;
    --text-org-desc:  #7a7570;
    --text-th:        #888077;
    --text-sep:       #d4cfc8;
    --score-bar-bg:   #e2ddd6;
    --email-dash:     #ccc8c0;
    --shadow-toast:   rgba(0,0,0,.2);
    --theme-icon:     "☾";
    --theme-label:    "Dark Mode";
  }}

  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    background: var(--bg-page);
    color: var(--text-primary);
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    transition: background .2s, color .2s;
  }}

  /* ── TOP BAR ── */
  .topbar {{
    background: var(--bg-surface);
    border-bottom: 1px solid var(--border);
    padding: 0 32px; height: 56px;
    display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 100;
    transition: background .2s, border-color .2s;
  }}
  .topbar-left {{ display: flex; align-items: center; gap: 20px; }}
  .logo {{ font-family: 'Cinzel', serif; font-size: 18px; color: #8E632F; font-weight: 700; letter-spacing: 2px; }}
  .logo-sep {{ color: var(--text-sep); font-size: 20px; }}
  .topbar-subtitle {{ font-size: 12px; color: var(--text-secondary); letter-spacing: 1px; }}
  .live-badge {{
    background: #10B981; color: #fff; font-size: 9px; font-weight: 700;
    letter-spacing: 2px; padding: 3px 10px; border-radius: 20px;
  }}
  .topbar-right {{ display: flex; align-items: center; gap: 10px; }}
  .updated {{ font-size: 10px; color: var(--text-faint); }}

  /* ── THEME TOGGLE ── */
  .theme-toggle {{
    display: flex; align-items: center; gap: 6px;
    background: var(--bg-copy); border: 1px solid var(--border-copy);
    color: var(--text-secondary); padding: 6px 12px; border-radius: 20px;
    cursor: pointer; font-family: 'Inter', sans-serif; font-size: 11px;
    font-weight: 600; letter-spacing: 0.5px; transition: all .2s;
    white-space: nowrap;
  }}
  .theme-toggle:hover {{ border-color: #8E632F; color: #C4A97D; }}
  .theme-icon {{ font-size: 13px; line-height: 1; }}

  /* ── BUTTONS ── */
  .btn {{
    background: #8E632F; color: #fff; border: none; padding: 7px 16px;
    font-size: 10px; font-weight: 700; letter-spacing: 1.5px; cursor: pointer;
    border-radius: 2px; font-family: 'Inter', sans-serif; transition: background .15s;
  }}
  .btn:hover {{ background: #a07038; }}
  .btn-ghost {{
    background: transparent; color: var(--text-secondary);
    border: 1px solid var(--border-copy);
    padding: 6px 14px; font-size: 10px; letter-spacing: 1px;
    cursor: pointer; border-radius: 2px; font-family: 'Inter', sans-serif;
    transition: all .15s;
  }}
  .btn-ghost:hover {{ border-color: #8E632F; color: #C4A97D; }}

  /* ── CONTENT ── */
  .content {{ max-width: 1400px; margin: 0 auto; padding: 28px 32px; }}

  /* ── DATE FILTER BAR ── */
  .date-bar {{
    background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px;
    padding: 16px 24px; margin-bottom: 20px;
    display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
    transition: background .2s, border-color .2s;
  }}
  .date-bar-label {{
    font-size: 10px; color: var(--text-secondary);
    letter-spacing: 2px; text-transform: uppercase; white-space: nowrap;
  }}
  .date-select {{
    background: var(--bg-input); border: 1px solid var(--border-input);
    color: #C4A97D; padding: 8px 14px; border-radius: 2px;
    font-family: 'Inter', sans-serif; font-size: 13px; font-weight: 600;
    cursor: pointer; outline: none; min-width: 260px; transition: all .2s;
  }}
  .date-select:focus {{ border-color: #8E632F; }}
  .date-nav {{ display: flex; gap: 6px; }}
  .date-nav-btn {{
    background: var(--bg-copy); border: 1px solid var(--border-copy);
    color: var(--text-secondary);
    padding: 7px 12px; font-size: 11px; cursor: pointer; border-radius: 2px;
    font-family: 'Inter', sans-serif; transition: all .15s;
  }}
  .date-nav-btn:hover {{ border-color: #8E632F; color: #C4A97D; }}
  .date-count {{ margin-left: auto; font-size: 11px; color: var(--text-muted); white-space: nowrap; }}

  /* ── STAT CARDS ── */
  .stats-row {{
    display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px;
  }}
  .stat-card {{
    background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px;
    padding: 18px 22px; transition: background .2s, border-color .2s;
  }}
  .stat-card.accent {{ border-color: #8E632F66; }}
  .stat-num {{ font-family: 'Cinzel', serif; font-size: 30px; font-weight: 700; color: #C4A97D; line-height: 1; }}
  .stat-num.green  {{ color: #10B981; }}
  .stat-num.blue   {{ color: #3B82F6; }}
  .stat-num.amber  {{ color: #F59E0B; }}
  .stat-label {{ font-size: 9px; letter-spacing: 2px; color: var(--text-muted); text-transform: uppercase; margin-top: 7px; }}
  .stat-sub {{ font-size: 11px; color: var(--text-faint); margin-top: 4px; }}

  /* ── TYPE CHIPS ── */
  .type-row {{ display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }}
  .type-chip {{
    display: flex; align-items: center; gap: 8px;
    background: var(--bg-surface); border: 1px solid var(--border); border-radius: 20px;
    padding: 7px 16px; cursor: pointer; transition: all .15s; white-space: nowrap;
  }}
  .type-chip:hover, .type-chip.active {{ border-color: var(--tc); }}
  .type-chip.active .type-chip-label {{ color: var(--tc); }}
  .type-dot {{ width: 8px; height: 8px; border-radius: 50%; background: var(--tc); }}
  .type-chip-label {{ font-size: 12px; font-weight: 600; color: var(--text-secondary); transition: color .15s; }}
  .type-chip-count {{ font-size: 11px; color: var(--text-muted); }}

  /* ── TABLE SECTION ── */
  .table-section {{
    background: var(--bg-surface); border: 1px solid var(--border); border-radius: 4px;
    transition: background .2s, border-color .2s;
  }}
  .table-header {{
    padding: 16px 24px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
  }}
  .table-title {{ font-family: 'Cinzel', serif; font-size: 13px; color: #C4A97D; font-weight: 700; }}
  .table-controls {{ display: flex; gap: 10px; align-items: center; }}
  .search-box {{
    background: var(--bg-input); border: 1px solid var(--border-input);
    color: var(--text-primary); padding: 6px 14px; border-radius: 2px;
    font-family: 'Inter', sans-serif; font-size: 12px; outline: none; width: 200px; transition: all .2s;
  }}
  .search-box:focus {{ border-color: #8E632F; }}
  .filter-select {{
    background: var(--bg-input); border: 1px solid var(--border-input);
    color: var(--text-secondary); padding: 6px 12px; border-radius: 2px;
    font-family: 'Inter', sans-serif; font-size: 11px; outline: none; cursor: pointer;
    transition: all .2s;
  }}
  .result-count {{ font-size: 11px; color: var(--text-muted); }}

  /* ── TABLE ── */
  .lead-table {{ width: 100%; border-collapse: collapse; }}
  .lead-table thead th {{
    padding: 10px 18px; text-align: left; font-size: 9px; letter-spacing: 2px;
    color: var(--text-th); font-weight: 700;
    background: var(--bg-surface-2); border-bottom: 1px solid var(--border);
    transition: background .2s;
  }}
  .lead-row {{ cursor: default; transition: background .1s; }}
  .lead-row:hover {{ background: var(--bg-row-hover); }}
  .lead-row td {{ padding: 13px 18px; border-bottom: 1px solid var(--border-subtle); vertical-align: middle; }}
  .org-name {{ font-weight: 600; color: var(--text-org); font-size: 13px; }}
  .org-name a {{ color: var(--text-org); text-decoration: none; }}
  .org-name a:hover {{ color: #C4A97D; }}
  .org-desc {{ font-size: 11px; color: var(--text-org-desc); margin-top: 3px; line-height: 1.4; }}
  .type-tag {{ display: inline-block; padding: 3px 9px; border-radius: 10px; font-size: 10px; font-weight: 700; letter-spacing: 0.5px; }}
  .score-cell {{ display: flex; align-items: center; gap: 7px; }}
  .score-bar-bg {{ flex: 1; height: 5px; background: var(--score-bar-bg); border-radius: 3px; max-width: 60px; }}
  .score-bar-fill {{ height: 5px; border-radius: 3px; }}
  .score-num {{ font-size: 11px; font-weight: 700; min-width: 14px; }}
  .status-tag {{ display: inline-block; padding: 3px 9px; border-radius: 10px; font-size: 10px; font-weight: 700; letter-spacing: 0.5px; }}
  .email-cell {{ font-size: 12px; }}
  .email-cell a {{ color: #C4A97D; text-decoration: none; }}
  .email-cell a:hover {{ color: #a07038; }}
  .copy-btn {{
    background: var(--bg-copy); border: 1px solid var(--border-copy);
    color: var(--text-secondary); padding: 5px 11px; font-size: 9px; letter-spacing: 1.5px;
    font-weight: 700; cursor: pointer; border-radius: 2px; font-family: 'Inter', sans-serif;
    transition: all .15s; white-space: nowrap;
  }}
  .copy-btn:hover {{ background: #8E632F22; border-color: #8E632F; color: #C4A97D; }}
  .empty-state {{ text-align: center; padding: 60px 0; color: var(--text-muted); font-size: 13px; }}
  .empty-state .empty-icon {{ font-size: 36px; margin-bottom: 12px; }}

  /* ── TOAST ── */
  #toast {{
    position: fixed; bottom: 28px; right: 28px; background: #10B981;
    color: #fff; padding: 11px 20px; border-radius: 4px; font-size: 12px;
    font-weight: 600; z-index: 9999; display: none; letter-spacing: 0.5px;
    box-shadow: 0 4px 20px var(--shadow-toast);
  }}

  /* ── RESPONSIVE ── */
  @media (max-width: 900px) {{
    .stats-row {{ grid-template-columns: repeat(2, 1fr); }}
    .content {{ padding: 16px; }}
    .topbar-subtitle {{ display: none; }}
  }}
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="topbar">
  <div class="topbar-left">
    <div class="logo">SYFER</div>
    <div class="logo-sep">|</div>
    <div class="topbar-subtitle">SARATOGA HOT SPRINGS RESORT · GROUP SALES INTELLIGENCE</div>
  </div>
  <div class="topbar-right">
    <span class="live-badge">● LIVE</span>
    <span class="updated">Updated: {now_str}</span>
    <button class="theme-toggle" id="theme-btn" onclick="toggleTheme()">
      <span class="theme-icon" id="theme-icon">☀</span>
      <span id="theme-label">Light Mode</span>
    </button>
    <button class="btn-ghost" onclick="exportCSV()">EXPORT CSV</button>
    <button class="btn" onclick="window.print()">PRINT</button>
  </div>
</div>

<!-- CONTENT -->
<div class="content">

  <!-- DATE FILTER BAR -->
  <div class="date-bar">
    <span class="date-bar-label">Viewing leads from</span>
    <select class="date-select" id="date-select" onchange="onDateChange(this.value)">
      {date_options_html}
    </select>
    <div class="date-nav">
      <button class="date-nav-btn" onclick="stepDate(-1)">&#8592; Prev</button>
      <button class="date-nav-btn" onclick="stepDate(1)">Next &#8594;</button>
    </div>
    <div class="date-count" id="date-total-count"></div>
  </div>

  <!-- STAT CARDS -->
  <div class="stats-row">
    <div class="stat-card accent">
      <div class="stat-num" id="stat-new">—</div>
      <div class="stat-label">New Leads This Day</div>
      <div class="stat-sub" id="stat-total-sub"></div>
    </div>
    <div class="stat-card">
      <div class="stat-num green" id="stat-high">—</div>
      <div class="stat-label">High Priority (8+)</div>
      <div class="stat-sub">Ready to contact</div>
    </div>
    <div class="stat-card">
      <div class="stat-num blue" id="stat-emails">—</div>
      <div class="stat-label">Emails Captured</div>
      <div class="stat-sub">From company pages</div>
    </div>
    <div class="stat-card">
      <div class="stat-num amber" id="stat-db">—</div>
      <div class="stat-label">Total Leads in DB</div>
      <div class="stat-sub">All time</div>
    </div>
  </div>

  <!-- TYPE FILTER CHIPS -->
  <div class="type-row">
    <div class="type-chip active" style="--tc:#C4A97D" onclick="filterType('all',this)">
      <div class="type-dot" style="background:#C4A97D"></div>
      <span class="type-chip-label">All Types</span>
      <span class="type-chip-count" id="chip-all">0</span>
    </div>
    <div class="type-chip" style="--tc:#3B82F6" onclick="filterType('Corporate',this)">
      <div class="type-dot"></div>
      <span class="type-chip-label">Corporate</span>
      <span class="type-chip-count" id="chip-Corporate">0</span>
    </div>
    <div class="type-chip" style="--tc:#10B981" onclick="filterType('Medical',this)">
      <div class="type-dot"></div>
      <span class="type-chip-label">Medical</span>
      <span class="type-chip-count" id="chip-Medical">0</span>
    </div>
    <div class="type-chip" style="--tc:#F59E0B" onclick="filterType('Outdoor',this)">
      <div class="type-dot"></div>
      <span class="type-chip-label">Outdoor</span>
      <span class="type-chip-count" id="chip-Outdoor">0</span>
    </div>
    <div class="type-chip" style="--tc:#8B5CF6" onclick="filterType('Nonprofit',this)">
      <div class="type-dot"></div>
      <span class="type-chip-label">Nonprofit</span>
      <span class="type-chip-count" id="chip-Nonprofit">0</span>
    </div>
  </div>

  <!-- LEAD TABLE -->
  <div class="table-section">
    <div class="table-header">
      <div class="table-title">Front Range Lead Intelligence</div>
      <div class="table-controls">
        <input class="search-box" type="text" placeholder="Search org or city..."
               oninput="onSearch(this.value)" id="search-input"/>
        <select class="filter-select" onchange="onStatusFilter(this.value)">
          <option value="all">All Status</option>
          <option value="New">New</option>
          <option value="Warm">Warm</option>
          <option value="Contacted">Contacted</option>
          <option value="Booked">Booked</option>
        </select>
        <span class="result-count" id="result-count"></span>
      </div>
    </div>
    <div style="overflow-x:auto;">
      <table class="lead-table">
        <thead>
          <tr>
            <th style="width:34%">ORGANIZATION</th>
            <th style="width:11%">TYPE</th>
            <th style="width:13%">PRIORITY</th>
            <th style="width:9%">STATUS</th>
            <th style="width:22%">EMAIL</th>
            <th style="width:11%">ACTION</th>
          </tr>
        </thead>
        <tbody id="lead-tbody">
          <tr><td colspan="6" class="empty-state">
            <div class="empty-icon">◈</div>
            Loading leads...
          </td></tr>
        </tbody>
      </table>
    </div>
  </div>

</div><!-- /content -->

<div id="toast">✓ Copied to clipboard</div>

<script>
// ── DATA ──────────────────────────────────────────────────────
const ALL_LEADS = {leads_json};

const TYPE_COLORS = {{
  Corporate: '#3B82F6', Medical: '#10B981',
  Outdoor: '#F59E0B', Nonprofit: '#8B5CF6', General: '#6B7280'
}};
const STATUS_COLORS = {{
  New: '#6B7280', Warm: '#F59E0B', Contacted: '#3B82F6',
  Booked: '#10B981', Dead: '#EF4444'
}};

// ── THEME ─────────────────────────────────────────────────────
function applyTheme(theme) {{
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('syfer-theme', theme);
  const isDark = theme === 'dark';
  document.getElementById('theme-icon').textContent  = isDark ? '☀' : '☾';
  document.getElementById('theme-label').textContent = isDark ? 'Light Mode' : 'Dark Mode';
}}

function toggleTheme() {{
  const current = document.documentElement.getAttribute('data-theme');
  applyTheme(current === 'dark' ? 'light' : 'dark');
}}

// Load saved theme on page load
(function() {{
  const saved = localStorage.getItem('syfer-theme');
  if (saved) applyTheme(saved);
  else applyTheme('dark');
}})();

// ── STATE ─────────────────────────────────────────────────────
let currentDate   = document.getElementById('date-select').value;
let activeType    = 'all';
let activeStatus  = 'all';
let searchQuery   = '';

window.addEventListener('DOMContentLoaded', () => renderAll());

// ── DATE CHANGE ───────────────────────────────────────────────
function onDateChange(val) {{
  currentDate  = val;
  activeType   = 'all';
  activeStatus = 'all';
  searchQuery  = '';
  document.getElementById('search-input').value = '';
  document.querySelectorAll('.filter-select').forEach(s => s.value = 'all');
  document.querySelectorAll('.type-chip').forEach(c => c.classList.remove('active'));
  document.querySelector('.type-chip').classList.add('active');
  renderAll();
}}

function stepDate(dir) {{
  const sel  = document.getElementById('date-select');
  const opts = Array.from(sel.options);
  const idx  = opts.findIndex(o => o.value === sel.value);
  const next = idx - dir;
  if (next >= 0 && next < opts.length) {{
    sel.value = opts[next].value;
    onDateChange(opts[next].value);
  }}
}}

// ── FILTERS ───────────────────────────────────────────────────
function filterType(type, el) {{
  activeType = type;
  document.querySelectorAll('.type-chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  renderTable();
}}

function onStatusFilter(val) {{ activeStatus = val; renderTable(); }}
function onSearch(val)       {{ searchQuery  = val.toLowerCase(); renderTable(); }}

// ── RENDER ────────────────────────────────────────────────────
function getDateLeads() {{
  return ALL_LEADS.filter(l => l.found_date === currentDate);
}}

function getFiltered() {{
  let leads = getDateLeads();
  if (activeType !== 'all')   leads = leads.filter(l => l.org_type === activeType);
  if (activeStatus !== 'all') leads = leads.filter(l => l.status   === activeStatus);
  if (searchQuery) leads = leads.filter(l =>
    (l.org_name||'').toLowerCase().includes(searchQuery) ||
    (l.city||'').toLowerCase().includes(searchQuery) ||
    (l.email||'').toLowerCase().includes(searchQuery)
  );
  return leads.sort((a, b) => b.score - a.score);
}}

function renderAll() {{
  const dl    = getDateLeads();
  const high  = dl.filter(l => l.score >= 8).length;
  const emails= dl.filter(l => l.email).length;

  document.getElementById('stat-new').textContent         = dl.length;
  document.getElementById('stat-high').textContent        = high;
  document.getElementById('stat-emails').textContent      = emails;
  document.getElementById('stat-db').textContent          = ALL_LEADS.length;
  document.getElementById('stat-total-sub').textContent   = ALL_LEADS.length + ' total in database';
  document.getElementById('date-total-count').textContent = dl.length + ' leads on this date';

  const types = ['Corporate','Medical','Outdoor','Nonprofit'];
  document.getElementById('chip-all').textContent = dl.length;
  types.forEach(t => {{
    const el = document.getElementById('chip-' + t);
    if (el) el.textContent = dl.filter(l => l.org_type === t).length;
  }});

  renderTable();
}}

function renderTable() {{
  const leads = getFiltered();
  document.getElementById('result-count').textContent = leads.length + ' shown';

  const tbody = document.getElementById('lead-tbody');
  if (!leads.length) {{
    tbody.innerHTML = `<tr><td colspan="6" class="empty-state">
      <div class="empty-icon">◈</div>No leads match your filters for this date.</td></tr>`;
    return;
  }}

  tbody.innerHTML = leads.map(l => {{
    const tc       = TYPE_COLORS[l.org_type] || '#6B7280';
    const sc       = STATUS_COLORS[l.status] || '#6B7280';
    const pct      = l.score * 10;
    const barColor = l.score >= 8 ? '#10B981' : l.score >= 6 ? '#F59E0B' : '#6B7280';
    const nameHtml = l.website
      ? `<a href="${{l.website}}" target="_blank" class="org-name">${{esc(l.org_name)}}</a>`
      : `<span class="org-name">${{esc(l.org_name)}}</span>`;
    const emailHtml = l.email
      ? `<a href="mailto:${{l.email}}">${{esc(l.email)}}</a>`
      : `<span style="color:var(--email-dash)">—</span>`;
    const copyData = [l.org_name, l.city+' CO', l.email, l.website].filter(Boolean).join(' | ');

    return `<tr class="lead-row">
      <td>
        ${{nameHtml}}
        <div class="org-desc">${{esc(l.city)}}, CO${{l.description ? ' · ' + esc(l.description) : ''}}</div>
      </td>
      <td><span class="type-tag" style="background:${{tc}}18;color:${{tc}};border:1px solid ${{tc}}44;">${{l.org_type}}</span></td>
      <td>
        <div class="score-cell">
          <div class="score-bar-bg"><div class="score-bar-fill" style="width:${{pct}}%;background:${{barColor}};"></div></div>
          <span class="score-num" style="color:${{barColor}};">${{l.score}}</span>
        </div>
      </td>
      <td><span class="status-tag" style="background:${{sc}}18;color:${{sc}};border:1px solid ${{sc}}44;">${{l.status}}</span></td>
      <td class="email-cell">${{emailHtml}}</td>
      <td><button class="copy-btn" onclick="copyText('${{esc(copyData.replace(/'/g,"\\'"))}}')">COPY</button></td>
    </tr>`;
  }}).join('');
}}

// ── UTILITIES ─────────────────────────────────────────────────
function esc(s) {{
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}}
function copyText(text) {{
  navigator.clipboard.writeText(text).then(() => {{
    const t = document.getElementById('toast');
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 2000);
  }});
}}
function exportCSV() {{
  const leads = getFiltered();
  const h = ['org_name','org_type','city','score','status','email','website','found_date'];
  const rows = leads.map(l => h.map(k => '"' + (l[k]||'').toString().replace(/"/g,'""') + '"').join(','));
  const blob = new Blob([[h.join(','), ...rows].join('\\n')], {{type:'text/csv'}});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'syfer_leads_' + currentDate + '.csv';
  a.click();
}}
</script>
</body>
</html>'''

    if output_path is None:
        output_path = os.path.join(os.path.dirname(__file__), '..', 'output', 'dashboard.html')

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"[Dashboard] Written → {output_path} ({len(all_leads)} leads, {len(all_dates)} dates)")
    return output_path


if __name__ == '__main__':
    path = generate()
    print(f"Dashboard: {path}")
