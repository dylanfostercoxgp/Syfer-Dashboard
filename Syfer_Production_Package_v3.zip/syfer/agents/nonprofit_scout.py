"""
Syfer — Nonprofit Scout
Returns raw DDGS search results for nonprofit/association group targets.
"""

ORG_TYPE = 'Nonprofit'

_EXCL = ' -site:yelp.com -site:tripadvisor.com -"best nonprofits" -"top 10" -"top 5" -"how to start"'

QUERIES = [
    'Denver nonprofit foundation organization Colorado' + _EXCL,
    'Denver nonprofit organization Colorado annual retreat' + _EXCL,
    'Colorado nonprofit association organization' + _EXCL,
    'Denver charitable foundation Colorado organization' + _EXCL,
    'Denver community foundation Colorado organization' + _EXCL,
    'Denver Chamber of Commerce Colorado organization' + _EXCL,
    'Boulder Chamber of Commerce Colorado organization' + _EXCL,
    'Fort Collins Chamber of Commerce Colorado organization' + _EXCL,
    'Colorado Springs Chamber of Commerce organization' + _EXCL,
    'Colorado civic organization leadership group' + _EXCL,
    'Colorado Rotary club organization Denver' + _EXCL,
    'Denver Lions club Colorado organization' + _EXCL,
    'Colorado professional association organization' + _EXCL,
    'Denver trade association Colorado organization' + _EXCL,
    'Colorado bar association member organization' + _EXCL,
    'Colorado realtors association organization Denver' + _EXCL,
    'Colorado builders association organization' + _EXCL,
    'Denver church group Colorado organization' + _EXCL,
    'Colorado large congregation church organization' + _EXCL,
    'Colorado school district administrative group' + _EXCL,
    'Denver alumni association Colorado organization' + _EXCL,
    'Colorado fraternal organization Denver' + _EXCL,
    'Denver women professional organization Colorado' + _EXCL,
    'Denver leadership program organization Colorado' + _EXCL,
    'Colorado homebuilders association Denver organization' + _EXCL,
]

SCORE_SIGNALS = [
    ('nonprofit', 2),
    ('foundation', 2),
    ('annual retreat', 3),
    ('board retreat', 3),
    ('leadership retreat', 3),
    ('chamber of commerce', 3),
    ('association', 2),
    ('501(c)', 3),
    ('executive director', 2),
    ('board of directors', 2),
    ('membership organization', 2),
    ('civic organization', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[NonprofitScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[NonprofitScout] {len(results)} raw results")
    return results
