"""
Syfer Lead Classifier
Determines whether a search result is:
  - 'company'   : a real organization/company homepage → add as lead
  - 'blog'      : article/listicle → extract companies mentioned inside
  - 'directory' : Yelp, BBB, etc. → extract business names from listing
  - 'skip'      : social media, gov, news, irrelevant → discard

Also provides company extraction from blog and directory pages.
"""

import re
from urllib.parse import urlparse
from bs4 import BeautifulSoup

# ─── DOMAIN CLASSIFIERS ──────────────────────────────────────

BLOG_DOMAINS = {
    'medium.com', 'substack.com', 'wordpress.com', 'blogspot.com',
    'hubspot.com', 'forbes.com', 'inc.com', 'entrepreneur.com',
    'businessinsider.com', 'marketwatch.com', 'huffpost.com',
    'theguardian.com', 'nytimes.com', 'washingtonpost.com',
    'coloradoan.com', 'denverpost.com', 'bizjournals.com',
    'coloradobiz.com', 'westword.com', '5280.com',
}

DIRECTORY_DOMAINS = {
    'yelp.com', 'tripadvisor.com', 'clutch.co', 'thumbtack.com',
    'angieslist.com', 'bbb.org', 'yellowpages.com', 'expertise.com',
    'bark.com', 'upcity.com', 'goodfirms.co', 'sortlist.com',
    'chamberofcommerce.com', 'manta.com', 'mapquest.com',
    'google.com/maps', 'bing.com/maps',
}

SKIP_DOMAINS = {
    'facebook.com', 'twitter.com', 'instagram.com', 'linkedin.com',
    'pinterest.com', 'tiktok.com', 'youtube.com', 'reddit.com',
    'wikipedia.org', 'wikimedia.org', 'gov', 'state.co.us',
    'coloradosos.gov', 'usa.gov', 'indeed.com', 'glassdoor.com',
    'ziprecruiter.com', 'monster.com', 'amazon.com', 'ebay.com',
    'etsy.com', 'eventbrite.com',
}

# URL path patterns that indicate a blog post
BLOG_PATH_PATTERNS = [
    '/blog/', '/article/', '/articles/', '/post/', '/posts/',
    '/news/', '/insights/', '/resources/', '/guide/', '/tips/',
    '/how-to/', '/list/', '/top-', '/best-', '/learn/',
    '/?p=', '/?s=',
]

# Title patterns that indicate a listicle/blog
LISTICLE_TITLE_PATTERNS = [
    r'^\d+\s+best\b', r'^\d+\s+top\b', r'^top\s+\d+',
    r'^best\s+\w+\s+in\b', r'^the\s+best\b', r'^a\s+guide\b',
    r'^how\s+to\b', r'^tips\s+for\b', r'^ideas\s+for\b',
    r'^what\s+is\b', r'^why\b', r'^complete\s+guide',
    r'\blist\s+of\b', r'\breviews?\b',
]


def classify(url: str, title: str = '', body: str = '') -> str:
    """
    Returns: 'company', 'blog', 'directory', or 'skip'
    """
    if not url:
        return 'skip'

    try:
        parsed = urlparse(url.lower())
        hostname = parsed.netloc.replace('www.', '')
        path = parsed.path
    except Exception:
        return 'skip'

    # Hard skips
    for skip in SKIP_DOMAINS:
        if skip in hostname:
            return 'skip'

    # Directories
    for d in DIRECTORY_DOMAINS:
        if d in hostname:
            return 'directory'

    # Known blog domains
    for b in BLOG_DOMAINS:
        if b in hostname:
            return 'blog'

    # Path-based blog detection
    for pat in BLOG_PATH_PATTERNS:
        if pat in path:
            return 'blog'

    # Title-based listicle detection
    title_lower = title.lower().strip()
    for pat in LISTICLE_TITLE_PATTERNS:
        if re.search(pat, title_lower):
            return 'blog'

    # Body signals: "here are the best..." "we compiled..."
    body_lower = body.lower()
    listicle_body_signals = [
        'here are the best', 'here are our top', 'we\'ve compiled',
        'the following companies', 'these companies offer',
        'top companies in', 'best companies in', 'list of companies',
    ]
    if any(sig in body_lower for sig in listicle_body_signals):
        return 'blog'

    return 'company'


# ─── COMPANY EXTRACTION FROM BLOGS ───────────────────────────

# Domains to skip when looking for company links in articles
ARTICLE_LINK_SKIP = {
    'google.com', 'facebook.com', 'twitter.com', 'instagram.com',
    'linkedin.com', 'youtube.com', 'pinterest.com', 'yelp.com',
    'amazon.com', 'apple.com', 'microsoft.com', 'wikipedia.org',
    'maps.google.com', 'goo.gl',
}


def extract_companies_from_blog(html: str, base_domain: str = '') -> list:
    """
    Parse a blog/article page and return list of:
      {'name': str, 'url': str}
    representing companies mentioned/linked in the article.
    """
    if not html:
        return []

    soup = BeautifulSoup(html, 'lxml')

    # Remove nav, footer, sidebar
    for tag in soup(['nav', 'footer', 'header', 'aside', 'script', 'style']):
        tag.decompose()

    companies = []
    seen_domains = set()

    # 1. External links with meaningful anchor text
    for a in soup.find_all('a', href=True):
        href = a.get('href', '')
        text = a.get_text(strip=True)

        if not href.startswith('http'):
            continue

        try:
            link_domain = urlparse(href).netloc.replace('www.', '')
        except Exception:
            continue

        # Skip own domain, skip known non-company domains
        if link_domain == base_domain:
            continue
        if any(skip in link_domain for skip in ARTICLE_LINK_SKIP):
            continue
        if link_domain in seen_domains:
            continue

        # Anchor text should look like a company name (not generic words)
        if not text or len(text) < 3 or len(text) > 60:
            continue
        if text.lower() in {'here', 'click', 'link', 'website', 'learn more',
                            'read more', 'source', 'visit', 'contact', 'more',
                            'view', 'see', 'details', 'info', 'home'}:
            continue

        # Reject names that look like article phrases
        text_words = text.lower().split()
        if text_words[0] in ('best', 'top', 'how', 'why', 'what', 'the', 'a', 'an'):
            if len(text_words) > 3:
                continue
        if any(w in text_words for w in ['is', 'are', 'was', 'will', 'should', 'can']):
            continue
        # Reject if starts with a number (listicle item)
        if text_words[0].isdigit():
            continue
        # Require at least 2 words for extracted names (single words too ambiguous)
        if len(text_words) < 2:
            continue

        # Looks like a real company link
        seen_domains.add(link_domain)
        companies.append({'name': text, 'url': href})

    # 2. Numbered/bulleted list items that look like company names
    if len(companies) < 3:
        for li in soup.find_all(['li', 'h2', 'h3', 'h4']):
            text = li.get_text(strip=True)
            # Skip very long or very short items
            if len(text) < 4 or len(text) > 60:
                continue
            words = text.split()
            # Require 2-6 words (proper company name length)
            if len(words) < 2 or len(words) > 6:
                continue
            # Skip if it looks like a sentence (has verb indicators)
            if any(w in text.lower() for w in [' is ', ' are ', ' was ', ' have ', ' will ',
                                                ' can ', ' should ', ' would ', ' the best ',
                                                ' how to ', ' why ', ' what ']):
                continue
            # Must start with capital letter (proper noun)
            if not text[0].isupper():
                continue
            # Reject if starts with a number
            if words[0].isdigit():
                continue
            # Reject common article headline starters
            if words[0].lower() in ('best', 'top', 'how', 'why', 'what', 'tips', 'guide'):
                continue
            # Reject all-caps headings (typically section headers, not names)
            if text.isupper() and len(words) > 2:
                continue
            # Avoid duplicates
            if any(c['name'].lower() == text.lower() for c in companies):
                continue
            companies.append({'name': text, 'url': ''})

    return companies[:15]  # Cap at 15 per article


def extract_companies_from_directory(html: str, url: str = '') -> list:
    """
    Parse a directory page (Yelp, BBB, etc.) and return list of
    {'name': str, 'url': str} for each business listed.
    """
    if not html:
        return []

    soup = BeautifulSoup(html, 'lxml')
    companies = []
    seen = set()

    # Generic: look for h3/h4 with business-looking names
    # and any linked business names
    for tag in soup.find_all(['h3', 'h4', 'h2']):
        text = tag.get_text(strip=True)
        if 2 < len(text) < 80 and text[0].isupper():
            text_key = text.lower()
            if text_key not in seen:
                seen.add(text_key)
                # Try to find an associated link
                link = tag.find('a', href=True)
                href = link['href'] if link else ''
                if href and not href.startswith('http'):
                    href = ''
                companies.append({'name': text, 'url': href})

    return companies[:15]
