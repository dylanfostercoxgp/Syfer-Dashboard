"""
Syfer — Outdoor Scout
Returns raw DDGS search results for outdoor group targets.
"""

ORG_TYPE = 'Outdoor'

_EXCL = ' -site:yelp.com -site:tripadvisor.com -site:alltrails.com -"best trails" -"top 10" -"top 5"'

QUERIES = [
    'Colorado hunting club Denver Front Range organization' + _EXCL,
    'Colorado hunting outfitter company Denver Boulder' + _EXCL,
    'Denver hunting fishing club Colorado membership organization' + _EXCL,
    'Colorado elk hunting club organization Denver' + _EXCL,
    'Colorado sportsman club Front Range organization' + _EXCL,
    'Denver ski club Colorado mountain group organization' + _EXCL,
    'Front Range ski club Denver snowboard group' + _EXCL,
    'Denver snowmobile club Colorado organization' + _EXCL,
    'Colorado snowmobile association organization' + _EXCL,
    'Colorado off road club Denver 4x4 organization' + _EXCL,
    'Colorado ATV side-by-side club Denver organization' + _EXCL,
    'Denver jeep club Colorado off road group' + _EXCL,
    'Colorado overland group Denver adventure club' + _EXCL,
    'Denver hiking club Colorado group organization' + _EXCL,
    'Colorado fourteener climbing club Denver organization' + _EXCL,
    'Denver trail running club Colorado organization' + _EXCL,
    'Colorado mountain biking club Denver Boulder organization' + _EXCL,
    'Boulder outdoor recreation club Colorado organization' + _EXCL,
    'Colorado adventure travel company Denver group' + _EXCL,
    'Front Range outdoor adventure company Colorado' + _EXCL,
    'Denver golf club private Colorado organization' + _EXCL,
    'Colorado golf association Denver group organization' + _EXCL,
    'Colorado equestrian club Denver Front Range organization' + _EXCL,
    'Denver fly fishing club Colorado organization' + _EXCL,
    'Colorado backcountry hunting club organization' + _EXCL,
]

SCORE_SIGNALS = [
    ('hunting', 3),
    ('elk', 3),
    ('snowmobile', 4),
    ('side-by-side', 4),
    ('atv', 3),
    ('off road', 3),
    ('ski club', 3),
    ('golf club', 2),
    ('outfitter', 3),
    ('adventure travel', 3),
    ('group trip', 3),
    ('annual trip', 3),
    ('club membership', 2),
    ('fly fishing', 3),
    ('backcountry', 3),
    ('wilderness', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[OutdoorScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[OutdoorScout] {len(results)} raw results")
    return results
