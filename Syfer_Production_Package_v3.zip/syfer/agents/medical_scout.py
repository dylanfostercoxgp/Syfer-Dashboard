"""
Syfer — Medical Scout
Returns raw DDGS search results for medical group targets.
"""

ORG_TYPE = 'Medical'

_EXCL = ' -site:yelp.com -site:tripadvisor.com -site:healthgrades.com -"best doctors" -"top 10" -"top 5"'

QUERIES = [
    'Denver hospital medical center staff retreat Colorado' + _EXCL,
    'Denver healthcare system group retreat Colorado' + _EXCL,
    'UCHealth Colorado group staff events' + _EXCL,
    'Denver Health hospital staff retreat Colorado' + _EXCL,
    'Children Hospital Colorado staff group events' + _EXCL,
    'Denver medical group physicians practice Colorado' + _EXCL,
    'Denver internal medicine group practice Colorado' + _EXCL,
    'Denver orthopedic group practice Colorado' + _EXCL,
    'Denver cardiology group practice Colorado' + _EXCL,
    'Denver dermatology group practice Colorado' + _EXCL,
    'Boulder medical group physicians practice Colorado' + _EXCL,
    'Fort Collins medical group physicians Colorado' + _EXCL,
    'Colorado Springs medical group practice Colorado' + _EXCL,
    'Denver dental group multi-location practice Colorado' + _EXCL,
    'Denver veterinary group practice Colorado' + _EXCL,
    'Colorado veterinary specialty group' + _EXCL,
    'Denver pharmaceutical company Colorado office' + _EXCL,
    'Denver medical device company Colorado' + _EXCL,
    'Colorado health technology company group retreat' + _EXCL,
    'Denver surgery center group practice Colorado' + _EXCL,
    'Colorado physician group practice management' + _EXCL,
    'Denver specialty clinic group practice Colorado' + _EXCL,
    'Front Range healthcare group retreat Colorado' + _EXCL,
    'Colorado medical association member organization' + _EXCL,
    'Denver hospital foundation group Colorado' + _EXCL,
]

SCORE_SIGNALS = [
    ('medical group', 3),
    ('physician group', 3),
    ('health system', 2),
    ('hospital', 2),
    ('multi-location', 3),
    ('staff retreat', 3),
    ('group practice', 3),
    ('practice management', 2),
    ('medical center', 2),
    ('specialty group', 2),
    ('healthcare group', 2),
    ('clinical group', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':    r.get('title', '').strip(),
                    'body':     r.get('body', '').strip(),
                    'url':      url,
                    'query':    query,
                    'org_type': ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[MedicalScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[MedicalScout] {len(results)} raw results")
    return results
