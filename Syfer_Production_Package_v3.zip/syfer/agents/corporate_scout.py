"""
Syfer — Corporate Scout
Returns raw DDGS search results for corporate group targets.
Classification, extraction, and DB insertion handled by orchestrator.
"""

ORG_TYPE = 'Corporate'

# DuckDuckGo exclusion suffix to filter out listicles & directories
_EXCL = ' -site:yelp.com -site:tripadvisor.com -site:thumbtack.com -"best companies" -"top 10" -"top 5"'

QUERIES = [
    'Denver corporate retreat planning company Colorado' + _EXCL,
    'Denver HR department team building events company' + _EXCL,
    'Denver event planning company corporate groups' + _EXCL,
    'Denver tech company headquarters Colorado groups' + _EXCL,
    'Denver financial services firm Colorado retreat' + _EXCL,
    'Denver law firm Colorado group retreat' + _EXCL,
    'Denver oil gas energy company Colorado' + _EXCL,
    'Boulder Colorado tech company corporate events' + _EXCL,
    'Boulder Colorado company HR offsite retreat' + _EXCL,
    'Fort Collins Colorado company corporate events' + _EXCL,
    'Fort Collins business corporate retreat Colorado' + _EXCL,
    'Colorado Springs corporate event planning company' + _EXCL,
    'Colorado Springs defense contractor company Colorado' + _EXCL,
    'Front Range Colorado corporate group travel planner' + _EXCL,
    'Colorado company annual retreat planning firm' + _EXCL,
    'Denver incentive travel corporate group company' + _EXCL,
    'Colorado corporate wellness retreat company' + _EXCL,
    'Denver large employer corporate group travel' + _EXCL,
    'Denver executive retreat planning company Colorado' + _EXCL,
    'Colorado leadership retreat corporate company' + _EXCL,
    'Denver association management company Colorado' + _EXCL,
    'Colorado meeting planning company group events' + _EXCL,
    'Denver corporate team building company Front Range' + _EXCL,
]

SCORE_SIGNALS = [
    ('team building', 2),
    ('corporate retreat', 3),
    ('annual retreat', 3),
    ('incentive travel', 3),
    ('group travel', 2),
    ('offsite', 2),
    ('event planner', 2),
    ('hr director', 2),
    ('hr manager', 2),
    ('employee experience', 2),
    ('company outing', 2),
    ('executive retreat', 3),
    ('wellness retreat', 2),
    ('leadership retreat', 3),
    ('headquarters', 1),
    ('planning company', 2),
    ('group events', 2),
]


def score(title: str, body: str) -> int:
    text = (title + ' ' + body).lower()
    s = 5
    for signal, pts in SCORE_SIGNALS:
        if signal in text:
            s += pts
    return min(10, max(1, s))


def run(ddgs, limit_per_query: int = 5) -> list:
    """Return raw search result dicts."""
    results = []
    seen_urls = set()

    for query in QUERIES:
        try:
            hits = ddgs.text(query, max_results=limit_per_query)
            for r in (hits or []):
                url = r.get('href', '').strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append({
                    'title':     r.get('title', '').strip(),
                    'body':      r.get('body', '').strip(),
                    'url':       url,
                    'query':     query,
                    'org_type':  ORG_TYPE,
                })
        except Exception as e:
            import time
            print(f"[CorporateScout] Error on '{query}': {e}")
            time.sleep(2)

    print(f"[CorporateScout] {len(results)} raw results")
    return results
